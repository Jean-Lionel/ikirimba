<?php

namespace App\Http\Controllers;

use App\Models\Colline;
use Illuminate\Http\Request;

class CollineController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        return view('colines.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Colline  $colline
     * @return \Illuminate\Http\Response
     */
    public function show(Colline $colline)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Colline  $colline
     * @return \Illuminate\Http\Response
     */
    public function edit(Colline $colline)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Colline  $colline
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Colline $colline)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Colline  $colline
     * @return \Illuminate\Http\Response
     */
    public function destroy(Colline $colline)
    {
        //
    }
}
