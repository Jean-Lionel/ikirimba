@extends('layouts.base')

@section('content')

<div>
	 <livewire:user-livewire />
	 
	 
</div>


@stop