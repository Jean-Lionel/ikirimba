@extends('layouts.base')

@section('content')

<div>
	 <livewire:member-list />
	 
	 
</div>


@stop