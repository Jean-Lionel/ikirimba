<div>
    {{ $counter }}
</div>
