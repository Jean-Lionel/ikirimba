@extends('layouts.base')

@section('content')

<div>
	 <livewire:groupements />
</div>


@stop