@extends('layouts.base')

@section('content')

<div>
	 <livewire:collines />
</div>


@stop