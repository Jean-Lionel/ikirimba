@extends('layouts.base')

@section('content')

<div>
	 <livewire:contribution-livewire />
</div>


@stop