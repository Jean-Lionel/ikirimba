@extends('layouts.base')

@section('content')

<div>

	<livewire:compte-info/>
</div>


@stop