@extends('layouts.base')

@section('content')

<div>

	<livewire:rapport-livewire></livewire:rapport-livewire>
</div>


@stop